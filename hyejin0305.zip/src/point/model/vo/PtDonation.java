package point.model.vo;

public class PtDonation {

}
