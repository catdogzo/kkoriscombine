package hospital.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hospital.model.service.HpService;
import hospital.model.vo.Hospital;

/**
 * Servlet implementation class HospitalServlet
 */
@WebServlet("/hospital.re")
public class HospitalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HospitalServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String Hp_Name = request.getParameter("Hp_Name");
		String Hp_Dname = request.getParameter("Hp_Dname");
		String Hp_Phone = request.getParameter("Hp_Phone");
		String Hp_Loc = request.getParameter("Hp_Loc");
		String Hp_Intro = request.getParameter("Hp_Intro");
	
		int Pet_Num = Integer.parseInt(request.getParameter("Pet_Num"));
		String Hm_Cate = request.getParameter("Hm_Cate");
		
		Hospital hospital = new Hospital(Hp_Id, Hp_Name, Hp_Dname, Hp_Phone, Hp_Loc, Hp_Intro, Hp_Photo, Hp_Start, Hp_End, Hp_Lunch);
		
		int result = new HpService().reserveHp();
		
		String page = null;
		if(result > 0) {
			page = "예약페이지";
		} else {
			page = "views/common/errorPage.jsp";
			request.setAttribute("msg", "병원 예약에 실패하였습니다.");
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
