package Location.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import Location.model.service.LocationService;
import hospital.model.vo.Hospital;

/**
 * Servlet implementation class LocationServlet
 */
@WebServlet("/location.se")
public class LocationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LocationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		LocationService service = new LocationService();
		String sidoGugun = request.getParameter("sido") +" "+ request.getParameter("gugun") + "%";
		ArrayList<Hospital> hList = service.selectList(sidoGugun);
		JSONObject listObj = null;
		JSONArray listArr = new JSONArray();
		
		for(int i = 0; i < hList.size(); i++) {
			
			listObj = new JSONObject();
			listObj.put("Hp_Name", hList.get(i).getHp_Name());
			listObj.put("Hp_Loc", hList.get(i).getHp_Loc());
			listObj.put("Hp_Phone", hList.get(i).getHp_Phone());
			
			listArr.add(listObj);
		}
		response.setContentType("application/json; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println(listArr);
		out.flush();
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
