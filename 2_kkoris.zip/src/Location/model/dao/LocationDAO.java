package Location.model.dao;

import static common.JDBCTemplate.*;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import hospital.model.vo.Hospital;

public class LocationDAO {
	
	public Properties prop = new Properties();
	
	public LocationDAO() {
		String fileName = LocationDAO.class.getResource("/sql/Location/location-query.properties").getPath();
		try {
			prop.load(new FileReader(fileName));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<Hospital> selectList(Connection conn, String sidoGugun) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<Hospital> list = null;
		
		String query = prop.getProperty("selectHospital");
		//selectHospital=SELECT * FROM HOSPITAL WHERE HP_LOC LIKE ?
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, sidoGugun);
			list = new ArrayList<Hospital>();
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				 list.add(new Hospital(rs.getString("hp_name"),
								  rs.getString("hp_phone"),
								  rs.getString("hp_loc")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(pstmt);
		}
		return list;
	}

}
