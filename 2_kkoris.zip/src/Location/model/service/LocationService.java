package Location.model.service;

import static common.JDBCTemplate.*;	

import java.sql.Connection;
import java.util.ArrayList;

import Location.model.dao.LocationDAO;
import hospital.model.vo.Hospital;

public class LocationService {

	public ArrayList<Hospital> selectList(String sidoGugun) {
		Connection conn = getConnection();
		
		ArrayList<Hospital> list = new LocationDAO().selectList(conn, sidoGugun);
		
		return list;
	}

}
